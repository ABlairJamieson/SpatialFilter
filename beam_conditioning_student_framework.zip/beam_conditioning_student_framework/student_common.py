"""Shared helpers for the student-facing beam-conditioning demos."""
from __future__ import annotations

from pathlib import Path
from beam_conditioning_core import gaussian_field

OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def student_default_input_field(grid):
    """
    Default input beam for the student-facing studies.

    Start with a circular Gaussian because it is easier to interpret. After the
    baseline is understood, replace this with one of the alternatives shown in
    the comments below.

    Suggested alternatives:
        elliptical_gaussian_field(grid, wx_mm=0.15, wy_mm=0.50, tilt_x_mrad=0.2)
        top_hat_field(grid, radius_mm=0.50)
        dirty_gaussian_field(grid, waist_radius_mm=0.35, amplitude_noise=0.10,
                             phase_noise_rad=0.25, seed=1)
    """
    return gaussian_field(
        grid,
        waist_radius_mm=0.35,
        tilt_x_mrad=0.0,
        tilt_y_mrad=0.0,
    )


def print_result_summary(label, result):
    """Compact one-line summary for comparing cases."""
    print(
        f"{label:45s}  "
        f"T={result.throughput:8.5f}  "
        f"outside={result.fraction_outside_target:12.4e}  "
        f"inside={100.0*(1.0-result.fraction_outside_target):9.5f}%  "
        f"rms={result.rms_radius_mm:8.4f} mm"
    )
